package com.admi.todolist;

import java.util.List;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * this class is the jax rs api interface
 * 
 * @author forrest yang
 *
 */
@Path("/thingtodoList")
public class ThingToDoController { 
 
	ThingToDoService thingService = new ThingToDoService();     
 
	
//basic CRUD operations
	
@GET
@Produces(MediaType.APPLICATION_JSON)
public List<ThingToDo> getthingtodoList() { 
 
    List<ThingToDo> listOfthingtodoList=thingService.getAllthingtodoList();
    return listOfthingtodoList;
}
 
@GET
@Path("/{id}")
@Produces(MediaType.APPLICATION_JSON)
public ThingToDo getThingById(@PathParam("id") int id) throws Exception {
    return thingService.getThing(id);
}       
 
@POST
@Produces(MediaType.APPLICATION_JSON)
public ThingToDo addThing(ThingToDo thingtodo) {
    return thingService.addThing(thingtodo);
}
 
@PUT
@Produces(MediaType.APPLICATION_JSON)
public ThingToDo updateThing(ThingToDo thingtodo) {
    return thingService.updateThing(thingtodo);
}     
 
@DELETE
@Path("/{id}")
@Produces(MediaType.APPLICATION_JSON)
public void deleteThing(@PathParam("id") int id) {
    thingService.deleteThing(id);
}
 
}