package com.admi.todolist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * this class is the service implemented logic for this api
 * 
 * @author forrest yang
 * 
 */
public class ThingToDoService {

	static HashMap<Integer, ThingToDo> thingIdMap = getthingIdMap();

	public ThingToDoService() {
		super();
		if (thingIdMap == null) {
			thingIdMap = new HashMap<Integer, ThingToDo>();

			// some example things to do
			ThingToDo a = new ThingToDo(1, "brush teeth", 20210801);
			ThingToDo b = new ThingToDo(2, "sing a song", 20210802);
			ThingToDo c = new ThingToDo(3, "wash dishes", 20210803);

			thingIdMap.put(1, a);
			thingIdMap.put(2, b);
			thingIdMap.put(3, c);

		}
	}

	public List<ThingToDo> getAllthingtodoList() {
		List<ThingToDo> thingtodoList = new ArrayList<ThingToDo>(thingIdMap.values());
		return thingtodoList;
	}

	public ThingToDo getThing(int id) throws Exception {
		ThingToDo thingtodo;
		synchronized (thingIdMap) {
			thingtodo = thingIdMap.get(id);
		}
		if (thingtodo == null) {
			throw new Exception("user with id " + id + " not found");
		}

		return thingtodo;
	}

	public ThingToDo addThing(ThingToDo thingtodo) {
		synchronized (thingIdMap) {
			thingtodo.setId(getMaxId() + 1);
			thingIdMap.put(thingtodo.getId(), thingtodo);
		}

		return thingtodo;
	}

	public  ThingToDo updateThing(ThingToDo thingtodo) {
		
		if (thingtodo.getId() <= 0)

			return null;
		synchronized (thingIdMap) {
			thingIdMap.put(thingtodo.getId(), thingtodo);
		}


		return thingtodo;
	}

	public synchronized void deleteThing(int id) {
		thingIdMap.remove(id);
	}

	public synchronized static HashMap<Integer, ThingToDo> getthingIdMap() {
		return thingIdMap;
	}

	// when generating new things to do, getMaxId() will help generate new id
	public synchronized static int getMaxId() {
		int max = 0;
		for (int id : thingIdMap.keySet()) {
			if (max <= id)
				max = id;
		}

		return max;

	}

}