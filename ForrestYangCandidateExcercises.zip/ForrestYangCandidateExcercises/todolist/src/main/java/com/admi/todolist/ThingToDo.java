package com.admi.todolist;

import java.time.LocalDate; // import the LocalDate class
import java.time.format.DateTimeFormatter; // Import the DateTimeFormatter class

/** 
 * this class is for the value object storing an item for the to do list
 * 
 * @author forrest yang
 * 
 */
public class ThingToDo {
	int id;
	String taskDesc;
	
	//date format "yyyy-MM-DD"
	long dueDate;
	
	//date format "yyyy-MM-DD"
	String creationDate;

	public ThingToDo()
     {
        super();
     }

	public ThingToDo(int i, String taskDesc, long dueDate)
     {
       super();
       this.id = i;
       this.taskDesc = taskDesc;
       
       this.dueDate = dueDate;
       
       //getting current date
       LocalDate myDateObj = LocalDate.now();
       DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyyMMdd");  
       
       String formattedDate = myDateObj.format(myFormatObj);
       this.creationDate = formattedDate;
     }

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getTaskDesc() {
		return taskDesc;
	}

	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}

	public long getdueDate() {
		return dueDate;
	}

	public void setdueDate(long dueDate) {
		this.dueDate = dueDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
